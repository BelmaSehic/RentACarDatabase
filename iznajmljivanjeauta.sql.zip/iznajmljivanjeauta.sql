-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: pipilica
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `car_information`
--

DROP TABLE IF EXISTS `car_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `car_information` (
  `car_id` int NOT NULL,
  `car_name` varchar(45) NOT NULL,
  `manifacturer_year` int NOT NULL,
  `daily_price` int NOT NULL,
  `car_type` varchar(45) NOT NULL,
  `manifacturer_id` int NOT NULL,
  `insurance_info` int NOT NULL,
  `is_available` enum('YES','NO') NOT NULL,
  `horse_power` int NOT NULL,
  `transmission` varchar(45) NOT NULL,
  `number_of_doors` enum('2','4') NOT NULL,
  `cubic_size` int NOT NULL,
  `millage_of_car` bigint NOT NULL,
  `registration_date` date NOT NULL,
  `rental_service_id` int NOT NULL,
  PRIMARY KEY (`car_id`),
  KEY `insurance_info_idx` (`insurance_info`),
  KEY `manifacturer_id_idx` (`manifacturer_id`),
  KEY `rental_service_id_idx` (`rental_service_id`),
  CONSTRAINT `insurance_info` FOREIGN KEY (`insurance_info`) REFERENCES `insurance` (`id_insurance`),
  CONSTRAINT `manifacturer_id` FOREIGN KEY (`manifacturer_id`) REFERENCES `manifacturer_company` (`id_manifacturer_company`),
  CONSTRAINT `rental_service_id` FOREIGN KEY (`rental_service_id`) REFERENCES `rental_point` (`rental_point_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `car_information`
--

LOCK TABLES `car_information` WRITE;
/*!40000 ALTER TABLE `car_information` DISABLE KEYS */;
INSERT INTO `car_information` VALUES (555,'BMW M3 BASE',2018,50,'Sedan',258,11,'YES',473,'6-Speed Manual','4',3,124144,'2021-04-23',12),(556,'AUDI Q3 S Line',2021,75,'Quattro',259,12,'YES',228,'8-Speed Automatic','4',2,414112,'2022-02-20',23),(557,'MERCEDES S550',2015,80,'Coupe',260,13,'NO',603,'7-Speed Automatic','2',5,642626,'2022-03-15',34),(558,'HYUNDAI Tuscon SE',2019,50,'SUV',261,14,'YES',181,'6-Speed Automatic','4',2,262463,'2021-10-31',12),(559,'VOLKSWAGEN Golf R',2015,40,'Hatchback',262,15,'YES',292,'6-Speed Automatic','4',2,552426,'2021-12-15',23);
/*!40000 ALTER TABLE `car_information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `city` (
  `city_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `postcode` int NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=334 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (111,'Sarajevo',71000),(222,'Mostar',88000),(333,'Tuzla',75000);
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `id_customer` int NOT NULL,
  `customer_first_name` varchar(45) NOT NULL,
  `customer_surname` varchar(45) NOT NULL,
  `customer_mobile_number` bigint NOT NULL,
  `customer_given_address` varchar(45) NOT NULL,
  PRIMARY KEY (`id_customer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (9887,'Mehmed','Spahic',38761234432,'Aleja lipa 4'),(9888,'Amila','Hodzic',38762109945,'Posavska 55'),(9889,'Benjamin','Delic',38763478563,'Vojnicki vrt 96'),(9890,'Dzan ','Tahirovic',38762123987,'Dolska 173'),(9891,'Sanja','Masic',38761506545,'Olovska 256');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `details_of_order`
--

DROP TABLE IF EXISTS `details_of_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `details_of_order` (
  `id_details_of_order` int NOT NULL,
  `number_of_days` int NOT NULL,
  `discount_for_cars` int NOT NULL,
  `details_of_ordercol` varchar(45) NOT NULL,
  `start_date` date NOT NULL,
  `total_amount` int NOT NULL,
  `order_number` int NOT NULL,
  `payment_number` int NOT NULL,
  PRIMARY KEY (`id_details_of_order`),
  KEY `order_number_idx` (`order_number`),
  KEY `payment_number_idx` (`payment_number`),
  CONSTRAINT `order_number` FOREIGN KEY (`order_number`) REFERENCES `orders` (`order_id`),
  CONSTRAINT `payment_number` FOREIGN KEY (`payment_number`) REFERENCES `payment` (`payment_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `details_of_order`
--

LOCK TABLES `details_of_order` WRITE;
/*!40000 ALTER TABLE `details_of_order` DISABLE KEYS */;
INSERT INTO `details_of_order` VALUES (888,5,5,'Child seat','2022-06-15',237,1,2267),(889,7,10,'GPS needed','2022-06-23',252,2,2268),(890,4,5,'Ski boxes','2022-07-01',266,3,2269),(891,9,10,'Child seat','2022-07-13',607,4,2270),(892,4,5,'//','2022-08-27',304,5,2271);
/*!40000 ALTER TABLE `details_of_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_salary`
--

DROP TABLE IF EXISTS `employee_salary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_salary` (
  `salary_id` int NOT NULL AUTO_INCREMENT,
  `amount` int NOT NULL,
  `payment_date` date NOT NULL,
  `employee_id` int NOT NULL,
  PRIMARY KEY (`salary_id`),
  KEY `employee_id_idx` (`employee_id`),
  CONSTRAINT `employee_id` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=681 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_salary`
--

LOCK TABLES `employee_salary` WRITE;
/*!40000 ALTER TABLE `employee_salary` DISABLE KEYS */;
INSERT INTO `employee_salary` VALUES (676,2500,'2001-06-20',101),(677,1800,'2001-06-20',102),(678,1800,'2001-06-20',103),(679,1500,'2001-06-20',104),(680,1500,'2001-06-20',105);
/*!40000 ALTER TABLE `employee_salary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `employee_id` int NOT NULL AUTO_INCREMENT,
  `e_first_name` varchar(45) NOT NULL,
  `e_last_name` varchar(45) NOT NULL,
  `e_date_birth` date NOT NULL,
  `e_mobile_number` bigint NOT NULL,
  `position_type` varchar(45) NOT NULL,
  `rentail_point_id` int NOT NULL,
  PRIMARY KEY (`employee_id`),
  KEY `rental_point_id_idx` (`rentail_point_id`),
  CONSTRAINT `rental_point_id` FOREIGN KEY (`rentail_point_id`) REFERENCES `rental_point` (`rental_point_id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (101,'Dino','Dinic','1980-01-01',38763345543,'CEO',12),(102,'Marko ','Savic','1981-02-03',38765234719,'sales manager',12),(103,'Sofija','Makic','1982-04-05',38761992334,'sales assistant',23),(104,'Edin ','Hrustic','1983-06-07',38761923451,'sales manager',23),(105,'Lamija','Dizdar','1984-12-12',38763567321,'sales assistant',34);
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insurance`
--

DROP TABLE IF EXISTS `insurance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insurance` (
  `id_insurance` int NOT NULL AUTO_INCREMENT,
  `price` int NOT NULL,
  `insurance_type` varchar(45) NOT NULL,
  `beginning_of_insurance` date NOT NULL,
  `insurance_expired` date NOT NULL,
  `is_insured` enum('yes','no') NOT NULL,
  PRIMARY KEY (`id_insurance`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insurance`
--

LOCK TABLES `insurance` WRITE;
/*!40000 ALTER TABLE `insurance` DISABLE KEYS */;
INSERT INTO `insurance` VALUES (11,800,'Liability coverage','2022-01-01','2022-12-31','yes'),(12,600,'Comprehensive insurance','2021-07-01','2022-07-01','yes'),(13,400,'Medical payments coverage','2022-01-01','2022-12-31','yes'),(14,500,'Collision Coverage','2022-01-02','2022-12-31','yes'),(15,800,'Liability coverage','2021-01-01','2021-12-31','no');
/*!40000 ALTER TABLE `insurance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manifacturer_company`
--

DROP TABLE IF EXISTS `manifacturer_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manifacturer_company` (
  `id_manifacturer_company` int NOT NULL,
  `manifacturer_company_name` varchar(45) NOT NULL,
  `manifacturer_description` varchar(50) NOT NULL,
  PRIMARY KEY (`id_manifacturer_company`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manifacturer_company`
--

LOCK TABLES `manifacturer_company` WRITE;
/*!40000 ALTER TABLE `manifacturer_company` DISABLE KEYS */;
INSERT INTO `manifacturer_company` VALUES (258,'BMW Group','M3 is a Sedan powered by S58 twin-turbo'),(259,'Volkswagen Group','Q3 is a Quattro with  2.0L turbocharged 4-cylinder'),(260,'Daimler AG','S550, Coupe with a turbocharged 4.7-liter engine'),(261,'Hyundai Motor Company','HYUNDAI Tucson SE SUV,7-inch screen, Apple CarPlay'),(262,'Volkswagen Group','Golf R is a Hatchback with 4Motion all-wheel drive');
/*!40000 ALTER TABLE `manifacturer_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `vehicle_id` int NOT NULL,
  `seller_id` int NOT NULL,
  `buyer_id` int NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `vehicle_id_idx` (`vehicle_id`),
  KEY `seller_id_idx` (`seller_id`),
  KEY `buyer_id_idx` (`buyer_id`),
  CONSTRAINT `buyer_id` FOREIGN KEY (`buyer_id`) REFERENCES `customer` (`id_customer`),
  CONSTRAINT `seller_id` FOREIGN KEY (`seller_id`) REFERENCES `employees` (`employee_id`),
  CONSTRAINT `vehicle_id` FOREIGN KEY (`vehicle_id`) REFERENCES `car_information` (`car_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,555,101,9887),(2,559,105,9891),(3,556,103,9888),(4,558,102,9890),(5,557,104,9889);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `payment_number` int NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  `payment_description` varchar(100) NOT NULL,
  PRIMARY KEY (`payment_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2272 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (2267,'Credit Card','Net 7 - Payment seven days after invoice date'),(2268,'Credit Card','Net 7 - Payment seven days after invoice date'),(2269,'Cash','PIA - Payment in advance'),(2270,'Credit Card','Net 7 - Payment seven days after invoice date'),(2271,'Cash','PIA - Payment in advance');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rental_point`
--

DROP TABLE IF EXISTS `rental_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rental_point` (
  `rental_point_id` int NOT NULL AUTO_INCREMENT,
  `address` varchar(45) NOT NULL,
  `phone_number` bigint NOT NULL,
  `city_id` bigint NOT NULL,
  `email_address` varchar(45) NOT NULL,
  PRIMARY KEY (`rental_point_id`),
  KEY `city_id_idx` (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rental_point`
--

LOCK TABLES `rental_point` WRITE;
/*!40000 ALTER TABLE `rental_point` DISABLE KEYS */;
INSERT INTO `rental_point` VALUES (12,'Trg Heroja 5',38762444555,111,'car_rent_sa@gmail.com'),(23,'Maršala Tita 24',38762789987,222,'car_rent_mo@gmail.com'),(34,'Mejdan 33',38761567987,333,'car_rent_tu@gmail.com');
/*!40000 ALTER TABLE `rental_point` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-04  0:00:30
